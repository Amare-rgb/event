import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    // Hostinger ላይ በሚገነባበት ወቅት የ TypeScript error ቢኖር እንኳን ቢልዱ እንዲቀጥል ያደርጋል
    ignoreBuildErrors: true,
  },
  ...(process.env.NODE_ENV !== "development" && {
    // ESLint type checking በ build ወቅት እንዲታለፍ
    eslint: {
      ignoreDuringBuilds: true,
    },
  }),
} as NextConfig;

export default nextConfig;